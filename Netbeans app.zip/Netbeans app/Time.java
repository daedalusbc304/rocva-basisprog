/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Time;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author Dell
 */
public class Time extends JFrame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       JFrame frame = new Time();
        frame.setSize (1000, 600);
        frame.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
        JPanel Optelpaneel = new Optelpaneel();
        frame.setContentPane(Optelpaneel);
        frame.setTitle( "Seconden omzetten");
        frame.setVisible( true ); 
}
}
    
    class Optelpaneel extends JPanel {
        private JTextField invoervak1, invoervak2, invoervak3, resultaatVak;
        private JButton plusKnop;
        private JButton dagKnop;
        private JButton uurKnop;
        private JButton minKnop;
        public Optelpaneel () {
        
            invoervak1 = new JTextField( 10 );
            invoervak2 = new JTextField( 10 );
            invoervak3 = new JTextField( 10 );
            resultaatVak = new JTextField( 20 );
            plusKnop = new JButton ("Laat resultaat zien");
            dagKnop = new JButton ("Aantal dagen"); 
            uurKnop = new JButton ("Aantal uur");
            minKnop = new JButton ("Aantal minuten");
            plusKnop.addActionListener( new PlusKnopHandler () );
            
            add( dagKnop);
            add( invoervak1);
            add( uurKnop);
            add( invoervak2);
            add( minKnop);
            add( invoervak3);
            add( plusKnop);
            add( resultaatVak);
            
            
        }
    class PlusKnopHandler implements ActionListener {
        public void actionPerformed ( ActionEvent e ) {
            String invoerstring1 = invoervak1.getText();
            int getal1 = Integer.parseInt(invoerstring1);
            
            String invoerstring2 = invoervak2.getText();
            int getal2 = Integer.parseInt(invoerstring2);
            
            String invoerstring3 = invoervak3.getText();
            int getal3 = Integer.parseInt(invoerstring3);
            
            int resultaat = getal1*86400 + getal2*3600 + getal3*60;
            resultaatVak.setText("Het aantal seconden is  " + resultaat);
            }
        }
    }


